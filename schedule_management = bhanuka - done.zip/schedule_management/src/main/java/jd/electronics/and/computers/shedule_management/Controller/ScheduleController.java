package jd.electronics.and.computers.shedule_management.Controller;

import jd.electronics.and.computers.shedule_management.Data.ScheduleDetails;
import jd.electronics.and.computers.shedule_management.Service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/schedules")
public class ScheduleController {

    @Autowired
    private ScheduleService scheduleService;

    // Create a new schedule
    @PostMapping
    public ScheduleDetails createSchedule(@RequestBody ScheduleDetails scheduleDetails) {
        return scheduleService.addSchedule(scheduleDetails);
    }

    // Get all schedules
    @GetMapping
    public List<ScheduleDetails> getAllSchedules() {
        return scheduleService.getAllSchedules();
    }

    // Get a schedule by ID
    @GetMapping("/{id}")
    public Optional<ScheduleDetails> getScheduleById(@PathVariable int id) {
        return scheduleService.getScheduleById(id);
    }

    // Update a schedule
    @PutMapping
    public ScheduleDetails updateSchedule(@RequestBody ScheduleDetails scheduleDetails) {
        return scheduleService.updateSchedule(scheduleDetails);
    }

    // Delete a schedule
    @DeleteMapping("/{id}")
    public void deleteSchedule(@PathVariable int id) {
        scheduleService.deleteSchedule(id);
    }
}
