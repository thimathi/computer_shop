package jd.electronics.and.computers.shedule_management.Data;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepository extends JpaRepository<ScheduleDetails, Integer> {
}
