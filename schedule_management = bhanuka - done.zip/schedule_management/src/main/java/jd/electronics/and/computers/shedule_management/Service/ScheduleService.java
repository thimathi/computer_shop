package jd.electronics.and.computers.shedule_management.Service;

import jd.electronics.and.computers.shedule_management.Data.ScheduleDetails;
import jd.electronics.and.computers.shedule_management.Data.ScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleService {

    @Autowired
    private ScheduleRepository scheduleRepository;

    // Add a new schedule
    public ScheduleDetails addSchedule(ScheduleDetails scheduleDetails) {
        return scheduleRepository.save(scheduleDetails);
    }

    // Get all schedules
    public List<ScheduleDetails> getAllSchedules() {
        return scheduleRepository.findAll();
    }

    // Get a schedule by ID
    public Optional<ScheduleDetails> getScheduleById(int id) {
        return scheduleRepository.findById(id);
    }

    // Update a schedule
    public ScheduleDetails updateSchedule(ScheduleDetails scheduleDetails) {
        return scheduleRepository.save(scheduleDetails);
    }

    // Delete a schedule by ID
    public void deleteSchedule(int id) {
        scheduleRepository.deleteById(id);
    }
}
