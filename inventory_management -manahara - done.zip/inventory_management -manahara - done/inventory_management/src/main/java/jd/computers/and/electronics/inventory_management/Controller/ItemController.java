package jd.computers.and.electronics.inventory_management.Controller;

import jd.computers.and.electronics.inventory_management.Data.ItemDetails;
import jd.computers.and.electronics.inventory_management.Data.ItemRepository;
import jd.computers.and.electronics.inventory_management.Service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ItemController {
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private ItemService itemService;

    @GetMapping(path = "/items")
    public List<ItemDetails> getAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping(path = "/items/{itemId}")
    public ItemDetails getItemById(@PathVariable int itemId) {
        return itemService.getItemById(itemId);
    }

    @PostMapping(path = "/items")
    public void addItem(@RequestBody ItemDetails itemDetails) {
        itemService.addItem(itemDetails);
    }

    @PutMapping(path = "/items/{itemId}")
    public void updateItem(@PathVariable int itemId, @RequestBody ItemDetails itemDetails) {
        itemService.updateItem(itemDetails);
    }

    @DeleteMapping(path = "/items/{itemId}")
    public void deleteItem(@PathVariable int itemId) {
        itemService.deleteItem(itemId);
    }
}
