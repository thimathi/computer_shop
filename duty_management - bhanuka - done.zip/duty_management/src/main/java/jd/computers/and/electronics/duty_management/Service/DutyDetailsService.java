package jd.computers.and.electronics.duty_management.Service;

import jd.computers.and.electronics.duty_management.Data.DutyDetails;
import jd.computers.and.electronics.duty_management.Data.DutyDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DutyDetailsService {

    @Autowired
    private DutyDetailsRepository dutyDetailsRepository;

    // Get all duties
    public List<DutyDetails> getAllDuties() {
        return dutyDetailsRepository.findAll();
    }

    // Get a specific duty by ID
    public DutyDetails getDutyById(Long id) {
        Optional<DutyDetails> duty = dutyDetailsRepository.findById(id);
        return duty.orElse(null); // Return null if the duty is not found
    }

    // Save or update a duty
    public DutyDetails saveDuty(DutyDetails dutyDetails) {
        return dutyDetailsRepository.save(dutyDetails);
    }

    // Delete a duty by ID
    public void deleteDuty(Long id) {
        dutyDetailsRepository.deleteById(id);
    }
}
