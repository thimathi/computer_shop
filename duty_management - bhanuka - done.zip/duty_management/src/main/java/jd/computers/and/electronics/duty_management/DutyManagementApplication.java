package jd.computers.and.electronics.duty_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DutyManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DutyManagementApplication.class, args);
	}

}
