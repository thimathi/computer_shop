package jd.computers.and.electronics.duty_management.Controller;

import jd.computers.and.electronics.duty_management.Data.DutyDetails;
import jd.computers.and.electronics.duty_management.Service.DutyDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/duties")
public class DutyController {

    @Autowired
    private DutyDetailsService dutyDetailsService;

    // Get all duties
    @GetMapping
    public List<DutyDetails> getAllDuties() {
        return dutyDetailsService.getAllDuties();
    }

    // Get a specific duty by ID
    @GetMapping("/{id}")
    public ResponseEntity<DutyDetails> getDutyById(@PathVariable Long id) {
        DutyDetails duty = dutyDetailsService.getDutyById(id);
        if (duty != null) {
            return new ResponseEntity<>(duty, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create a new duty
    @PostMapping
    public ResponseEntity<DutyDetails> createDuty(@RequestBody DutyDetails dutyDetails) {
        DutyDetails savedDuty = dutyDetailsService.saveDuty(dutyDetails);
        return new ResponseEntity<>(savedDuty, HttpStatus.CREATED);
    }

    // Update an existing duty
    @PutMapping("/{id}")
    public ResponseEntity<DutyDetails> updateDuty(@PathVariable Long id, @RequestBody DutyDetails dutyDetails) {
        dutyDetails.setDutyId(id);  // Ensure the ID is set in the entity
        DutyDetails updatedDuty = dutyDetailsService.saveDuty(dutyDetails);
        return new ResponseEntity<>(updatedDuty, HttpStatus.OK);
    }

    // Delete a duty
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDuty(@PathVariable Long id) {
        dutyDetailsService.deleteDuty(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
