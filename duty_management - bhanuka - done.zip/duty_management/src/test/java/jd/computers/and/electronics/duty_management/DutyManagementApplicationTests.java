package jd.computers.and.electronics.duty_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DutyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
