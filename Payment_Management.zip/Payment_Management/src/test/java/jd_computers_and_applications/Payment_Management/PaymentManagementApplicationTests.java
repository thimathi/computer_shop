package jd_computers_and_applications.Payment_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
