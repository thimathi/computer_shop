package jd.computers.and.electronics.payment_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
