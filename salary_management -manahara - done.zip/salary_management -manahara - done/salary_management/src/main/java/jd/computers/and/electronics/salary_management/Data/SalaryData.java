package jd.computers.and.electronics.salary_management.Data;

import jakarta.persistence.*;

@Entity
@Table(name = "salary")
public class SalaryData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Salary_ID")
    private int id;

    @Column(name = "Employee_ID")
    private int employeeId;

    @Column(name = "amount")
    private double amount;

    @Column(name = "status")
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
