package jd.computers.and.electronics.salary_management.Service;


import jd.computers.and.electronics.salary_management.Data.SalaryData;
import jd.computers.and.electronics.salary_management.Data.SalaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalaryService {

    @Autowired
    private SalaryRepository salaryRepository;

    public List<SalaryData> getAllSalaries() {
        return salaryRepository.findAll();
    }

    public SalaryData getSalaryById(int id) {
        Optional<SalaryData> salaryData = salaryRepository.findById(id);
        if (salaryData.isPresent()) {
            return salaryData.get();
        }
        return null;
    }

    public SalaryData createSalary(SalaryData salaryData) {
        return salaryRepository.save(salaryData);
    }
    public SalaryData updateSalary(SalaryData salaryData) {
        if(salaryRepository.existsById(salaryData.getId())) {
            return salaryRepository.save(salaryData);
        }
        return null;
    }

    public void deleteSalary(Integer id) {
        if(salaryRepository.existsById(id)) {
            salaryRepository.deleteById(id);
        }
        else{
            System.out.println("Salary not found");
        }
    }
}

