package jd.computers.and.electronics.salary_management.Controller;


import jd.computers.and.electronics.salary_management.Data.SalaryData;
import jd.computers.and.electronics.salary_management.Service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class SalaryController {

    @Autowired
    private SalaryService salaryService;

    @GetMapping(path = "/salary")
    public List<SalaryData> findAllSalaries() {
        return salaryService.getAllSalaries();
    }

    @GetMapping(path = "/salary/{salaryId}")
    public SalaryData findSalaryById(@PathVariable int salaryId) {
        return salaryService.getSalaryById(salaryId);
    }

    @PostMapping(path = "/salary")
    public SalaryData saveSalary(@RequestBody SalaryData salaryData) {
        return salaryService.createSalary(salaryData);
    }

    @PutMapping(path = "/salary/{salaryId}")
    public SalaryData updateSalary(@PathVariable int salaryId, @RequestBody SalaryData salaryData) {
        return salaryService.updateSalary(salaryData);
    }

    @DeleteMapping(path = "/salary/{salaryId}")
    public void deleteSalary(@PathVariable Integer salaryId) {
        if(salaryId != null) {
            salaryService.deleteSalary(salaryId);
        }
        else {
            System.out.println("Salary id is null");
        }
    }
}
