package jd.computers.and.electronics.inventory_management.Service;

import jd.computers.and.electronics.inventory_management.Data.ItemDetails;
import jd.computers.and.electronics.inventory_management.Data.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {
    @Autowired
    private ItemRepository itemRepository;
    public List<ItemDetails> getAllItems() {
        return itemRepository.findAll();
    }
    public ItemDetails getItemById(int id) {
        Optional<ItemDetails> item = itemRepository.findById(id);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }
    public ItemDetails addItem(ItemDetails item) {
        return itemRepository.save(item);
    }
    public ItemDetails updateItem(ItemDetails item) {
        if(itemRepository.existsById(item.getItemID())) {
           return itemRepository.save(item);
        }
        return null;
    }
    public void deleteItem(int id) {
        itemRepository.deleteById(id);
    }
}
