package jd.computers.and.electronics.inventory_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
