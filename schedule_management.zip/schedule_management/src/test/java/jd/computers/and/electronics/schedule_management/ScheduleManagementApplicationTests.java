package jd.computers.and.electronics.schedule_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
