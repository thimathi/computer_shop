package jd_computers_and_applications.Stock_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
