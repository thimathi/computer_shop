package jd.computers.and.electronics.customer_management.Controller;

import jd.computers.and.electronics.customer_management.Data.CustomerDetails;
import jd.computers.and.electronics.customer_management.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping(path = "/customer")
    public List<CustomerDetails> findAllCustomers() {
        return customerService.getAllCustomers();
    }

    @GetMapping(path = "/customer/{customerId}")
    public CustomerDetails findCustomerById(@PathVariable int customerId) {
        return customerService.getCustomerDetailsById(customerId);
    }

    @PostMapping(path = "/customer")
    public CustomerDetails saveCustomer(@RequestBody CustomerDetails customerDetails) {
        return customerService.createCustomer(customerDetails);
    }

    @PutMapping(path = "/customer")
    public CustomerDetails updateCustomer(@RequestBody CustomerDetails customerDetails) {
        return customerService.updateCustomer(customerDetails);
    }

    @DeleteMapping(path = "/customer/{customerId}")
    public void deleteCustomer(@PathVariable Integer customerId) {
        if (customerId != null){
            customerService.deleteCustomer(customerId);
        }
        else {
            System.out.println("Customer id is null");
        }
    }
}
