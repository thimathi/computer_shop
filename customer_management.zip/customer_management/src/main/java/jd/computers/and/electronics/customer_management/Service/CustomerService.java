package jd.computers.and.electronics.customer_management.Service;

import jd.computers.and.electronics.customer_management.Data.CustomerDetails;
import jd.computers.and.electronics.customer_management.Data.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public List<CustomerDetails> getAllCustomers() {
        return customerRepository.findAll();
    }

    public CustomerDetails getCustomerDetailsById(int id) {
        Optional<CustomerDetails> customerDetails = customerRepository.findById(id);
        if (customerDetails.isPresent()) {
            return customerDetails.get();
        }
        return null;
    }

    public CustomerDetails createCustomer(CustomerDetails customerDetails) {
        return customerRepository.save(customerDetails);
    }

    public CustomerDetails updateCustomer(CustomerDetails customerDetails) {
        if (customerRepository.existsById(customerDetails.getId())) {
            return customerRepository.save(customerDetails);
        }
        return null;
    }
    public void deleteCustomer(Integer id) {
        if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);
        }
        else {
            System.out.println("Customer not found");
        }
    }
}
