package jd.computers.and.electronics.invoice_management.Service;

import jd.computers.and.electronics.invoice_management.Data.InvoiceDetails;
import jd.computers.and.electronics.invoice_management.Data.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    public List<InvoiceDetails> getInvoiceDetails() {
        return invoiceRepository.findAll();
    }
    public InvoiceDetails getInvoiceDetails(int id) {
        Optional<InvoiceDetails> invoiceDetails = invoiceRepository.findById(id);
        return invoiceDetails.orElse(null);
    }
    public InvoiceDetails saveInvoiceDetails(InvoiceDetails invoiceDetails) {
        return invoiceRepository.save(invoiceDetails);
    }
    public InvoiceDetails updateInvoiceDetails(InvoiceDetails invoiceDetails) {
        return invoiceRepository.save(invoiceDetails);
    }
    public void deleteInvoiceDetails(int id) {
        invoiceRepository.deleteById(id);
    }
}
