package jd.computers.and.electronics.invoice_management.Controller;

import jd.computers.and.electronics.invoice_management.Data.InvoiceDetails;
import jd.computers.and.electronics.invoice_management.Service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @GetMapping(path = "/invoice")
    public List<InvoiceDetails> getInvoiceDetails() {
        return invoiceService.getInvoiceDetails();
    }

    @GetMapping(path = "/invoice/{invoiceId}")
    public InvoiceDetails getInvoiceDetails(@PathVariable int invoiceID) {
        return invoiceService.getInvoiceDetails(invoiceID);
    }

    @PostMapping(path = "/invoice")
    public InvoiceDetails addInvoiceDetails(@RequestBody InvoiceDetails invoiceDetails) {
        return invoiceService.saveInvoiceDetails(invoiceDetails);
    }

    @PutMapping(path = "/invoice")
    public InvoiceDetails updateInvoiceDetails(@RequestBody InvoiceDetails invoiceDetails) {
        return invoiceService.updateInvoiceDetails(invoiceDetails);
    }

    @DeleteMapping(path = "/invoice/{invoiceID}")
    public void deleteInvoice(@PathVariable Integer invoiceID) {
        if (invoiceID != null) {
            invoiceService.deleteInvoiceDetails(invoiceID);
        }
        else {
            System.out.println("Invoice ID is null");
        }
    }

}
