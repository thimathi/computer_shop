package jd.computers.and.electronics.order_management.Service;

import jd.computers.and.electronics.order_management.Data.Cart;
import jd.computers.and.electronics.order_management.Data.CartItem;
import jd.computers.and.electronics.order_management.Data.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public Cart getCartByCustomerId(int customerId) {
        return cartRepository.findByCustomerId(customerId);
    }

    public Cart addItemToCart(int customerId, CartItem cartItem) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart == null) {
            cart = new Cart();
            cart.setCustomerId(customerId);
        }
        cart.getCartItems().add(cartItem);
        return cartRepository.save(cart);
    }

    public Cart removeItemFromCart(int customerId, int itemId) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart != null) {
            cart.getCartItems().removeIf(item -> item.getItemId() == itemId);
            cartRepository.save(cart);
        }
        return cart;
    }

    public void clearCart(int customerId) {
        Cart cart = cartRepository.findByCustomerId(customerId);
        if (cart != null) {
            cart.getCartItems().clear();
            cartRepository.save(cart);
        }
    }
}
