package jd.computers.and.electronics.order_management.Controller;

import jd.computers.and.electronics.order_management.Data.OrderDetails;
import jd.computers.and.electronics.order_management.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create an order
    @PostMapping
    public ResponseEntity<OrderDetails> createOrder(@RequestBody OrderDetails orderDetails) {
        OrderDetails createdOrder = orderService.createOrder(orderDetails);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
    }

    // Get an order by ID
    @GetMapping("/{id}")
    public ResponseEntity<OrderDetails> getOrderById(@PathVariable int id) {
        return orderService.getOrderById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Get all orders
    @GetMapping
    public ResponseEntity<List<OrderDetails>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    // Update an order
    @PutMapping("/{id}")
    public ResponseEntity<OrderDetails> updateOrder(@PathVariable int id, @RequestBody OrderDetails updatedOrder) {
        try {
            return ResponseEntity.ok(orderService.updateOrder(id, updatedOrder));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete an order
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable int id) {
        orderService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }
}
