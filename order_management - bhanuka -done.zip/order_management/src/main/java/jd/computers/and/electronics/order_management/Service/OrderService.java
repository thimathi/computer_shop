package jd.computers.and.electronics.order_management.Service;

import jd.computers.and.electronics.order_management.Data.OrderDetails;
import jd.computers.and.electronics.order_management.Data.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    // Create an order
    public OrderDetails createOrder(OrderDetails orderDetails) {
        return orderRepository.save(orderDetails);
    }

    // Get an order by ID
    public Optional<OrderDetails> getOrderById(int orderId) {
        return orderRepository.findById(orderId);
    }

    // Get all orders
    public List<OrderDetails> getAllOrders() {
        return orderRepository.findAll();
    }

    // Update an order
    public OrderDetails updateOrder(int orderId, OrderDetails updatedOrder) {
        return orderRepository.findById(orderId).map(order -> {
            order.setName(updatedOrder.getName());
            order.setStatus(updatedOrder.getStatus());
            order.setAmount(updatedOrder.getAmount());
            order.setFinalDate(updatedOrder.getFinalDate());
            return orderRepository.save(order);
        }).orElseThrow(() -> new RuntimeException("Order not found"));
    }

    // Delete an order
    public void deleteOrder(int orderId) {
        orderRepository.deleteById(orderId);
    }
}
