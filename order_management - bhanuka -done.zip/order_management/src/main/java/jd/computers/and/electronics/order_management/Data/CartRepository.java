package jd.computers.and.electronics.order_management.Data;

import jd.computers.and.electronics.order_management.Data.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Integer> {
    Cart findByCustomerId(int customerId);
}
