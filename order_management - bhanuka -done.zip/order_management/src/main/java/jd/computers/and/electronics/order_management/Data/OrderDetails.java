package jd.computers.and.electronics.order_management.Data;

import jakarta.persistence.*; // Correct imports
import jd.computers.and.electronics.customer_management.CustomerDetails; // Correct import for CustomerDetails
import java.util.Date;

@Entity
@Table(name = "Orders")
public class OrderDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Order_ID")
    private int orderId;

    @ManyToOne
    @JoinColumn(name = "Customer_ID", nullable = false) // Correctly links to CustomerDetails
    private CustomerDetails customer; // Fixed type to correctly reference CustomerDetails

    @Column(name = "Name")
    private String name;

    @Column(name = "Status")
    private String status;

    @Column(name = "Amount")
    private double amount;

    @Column(name = "Final_Date")
    @Temporal(TemporalType.DATE) // Explicitly set temporal type for Date
    private Date finalDate;

    // Getters and setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public CustomerDetails getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDetails customer) {
        this.customer = customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getFinalDate() {
        return finalDate;
    }

    public void setFinalDate(Date finalDate) {
        this.finalDate = finalDate;
    }
}
