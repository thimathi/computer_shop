package jd.computers.and.electronics.order_management.Controller;

import jd.computers.and.electronics.order_management.Data.Cart;
import jd.computers.and.electronics.order_management.Data.CartItem;
import jd.computers.and.electronics.order_management.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping("/{customerId}")
    public Cart getCart(@PathVariable int customerId) {
        return cartService.getCartByCustomerId(customerId);
    }

    @PostMapping("/{customerId}/add")
    public Cart addItem(@PathVariable int customerId, @RequestBody CartItem cartItem) {
        return cartService.addItemToCart(customerId, cartItem);
    }

    @DeleteMapping("/{customerId}/remove/{itemId}")
    public Cart removeItem(@PathVariable int customerId, @PathVariable int itemId) {
        return cartService.removeItemFromCart(customerId, itemId);
    }

    @DeleteMapping("/{customerId}/clear")
    public void clearCart(@PathVariable int customerId) {
        cartService.clearCart(customerId);
    }
}
