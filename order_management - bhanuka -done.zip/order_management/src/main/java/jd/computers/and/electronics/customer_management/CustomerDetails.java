package jd.computers.and.electronics.customer_management;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "customer")
public class CustomerDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Customer_ID")
    private int id;

    @Column(name = "Add_Date")
    private Date addDate;

    @Column(name = "Tp_Number")
    private long tpNumber;

    @Column(name = "Customer_Name")
    private String customerName;

    @Column(name = "UserType_ID")
    final int userTypeID = 8;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public long getTpNumber() {
        return tpNumber;
    }

    public void setTpNumber(long tpNumber) {
        this.tpNumber = tpNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
